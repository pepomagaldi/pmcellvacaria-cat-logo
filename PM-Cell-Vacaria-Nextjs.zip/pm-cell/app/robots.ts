import type { MetadataRoute } from "next";
import { siteUrl } from "@/lib/catalog";
export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      ...(siteUrl ? { allow: "/" } : { disallow: "/" }),
    },
    ...(siteUrl ? { sitemap: `${siteUrl}/sitemap.xml` } : {}),
  };
}
